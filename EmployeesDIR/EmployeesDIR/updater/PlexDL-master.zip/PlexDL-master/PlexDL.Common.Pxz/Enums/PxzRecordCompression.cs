﻿namespace PlexDL.Common.Pxz.Enums
{
    public enum PxzRecordCompression
    {
        None,
        GZip,
        ZLib
    }
}