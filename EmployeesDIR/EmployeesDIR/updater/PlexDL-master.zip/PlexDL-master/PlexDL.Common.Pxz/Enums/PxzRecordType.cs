﻿namespace PlexDL.Common.Pxz.Enums
{
    public enum PxzRecordType
    {
        Byte,
        Text,
        Xml,
        Json,
        Bitmap
    }
}