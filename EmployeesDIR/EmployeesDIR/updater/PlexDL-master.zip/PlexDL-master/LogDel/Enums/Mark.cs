﻿namespace LogDel.Enums
{
    public enum Mark
    {
        Encrypted,
        Decrypted
    }
}