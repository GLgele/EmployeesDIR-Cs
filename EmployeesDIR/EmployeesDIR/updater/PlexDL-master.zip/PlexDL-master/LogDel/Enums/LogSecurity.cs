﻿namespace LogDel.Enums
{
    public enum LogSecurity
    {
        Protected,
        Unprotected
    }
}