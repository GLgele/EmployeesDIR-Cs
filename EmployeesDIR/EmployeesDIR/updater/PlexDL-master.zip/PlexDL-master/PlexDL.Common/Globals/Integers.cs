﻿namespace PlexDL.Common.Globals
{
    public static class Integers
    {
        public static int SessionIdLength { get; } = 10;
    }
}