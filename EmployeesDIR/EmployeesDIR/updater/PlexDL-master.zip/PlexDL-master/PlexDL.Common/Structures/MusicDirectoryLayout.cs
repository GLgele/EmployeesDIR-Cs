﻿namespace PlexDL.Common.Structures
{
    public class MusicDirectoryLayout
    {
        public string ArtistPath { get; set; } = "";
        public string AlbumPath { get; set; } = "";
        public string BasePath { get; set; } = "";
    }
}