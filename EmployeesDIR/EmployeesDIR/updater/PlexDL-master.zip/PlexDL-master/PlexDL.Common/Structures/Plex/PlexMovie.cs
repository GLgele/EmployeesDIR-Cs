﻿using System;

namespace PlexDL.Common.Structures.Plex
{
    [Serializable]
    public class PlexMovie : PlexObject
    {
        //used as a placeholder for a future feature :) It doesn't contain modifiable data yet, but it is planned for the future.
    }
}