﻿namespace PlexDL.Common.Structures.AppOptions.Player
{
    public enum PlaybackMode
    {
        PvsPlayer,
        VlcPlayer,
        Browser,
        MenuSelector
    }
}