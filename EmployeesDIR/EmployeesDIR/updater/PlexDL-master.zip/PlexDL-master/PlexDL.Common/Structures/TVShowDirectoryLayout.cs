﻿namespace PlexDL.Common.Structures
{
    public class TvShowDirectoryLayout
    {
        public string TitlePath { get; set; } = "";
        public string SeasonPath { get; set; } = "";
        public string BasePath { get; set; } = "";
    }
}