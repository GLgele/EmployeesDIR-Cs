﻿namespace PlexDL.Common.Structures
{
    public class StreamLinks
    {
        public string Download { get; set; } = null;
        public string View { get; set; } = null;
    }
}