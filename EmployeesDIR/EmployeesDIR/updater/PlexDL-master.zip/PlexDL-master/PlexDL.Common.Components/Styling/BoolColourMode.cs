﻿namespace PlexDL.Common.Components.Styling
{
    public enum BoolColourMode
    {
        BackColour,
        ForeColour
    }
}