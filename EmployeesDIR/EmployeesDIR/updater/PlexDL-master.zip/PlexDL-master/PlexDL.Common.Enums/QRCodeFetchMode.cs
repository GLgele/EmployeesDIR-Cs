﻿namespace PlexDL.Common.Enums
{
    public enum QRCodeFetchMode
    {
        Online,
        Offline
    }
}