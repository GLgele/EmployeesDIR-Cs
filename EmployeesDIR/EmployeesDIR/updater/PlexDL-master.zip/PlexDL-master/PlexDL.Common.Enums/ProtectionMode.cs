﻿namespace PlexDL.Common.Enums
{
    public enum ProtectionMode
    {
        Encrypt,
        Decrypt
    }
}