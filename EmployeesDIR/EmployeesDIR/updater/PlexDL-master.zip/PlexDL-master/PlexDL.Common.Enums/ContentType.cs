﻿namespace PlexDL.Common.Enums
{
    public enum ContentType
    {
        TvShows,
        Movies,
        Music
    }
}