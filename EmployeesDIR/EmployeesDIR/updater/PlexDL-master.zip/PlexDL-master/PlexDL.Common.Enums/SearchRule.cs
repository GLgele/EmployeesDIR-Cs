﻿namespace PlexDL.Common.Enums
{
    public enum SearchRule
    {
        ContainsKey,
        EqualsKey,
        BeginsWith,
        EndsWith
    }
}