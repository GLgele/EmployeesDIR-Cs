﻿namespace PlexDL.Common.Enums
{
    public enum DevStatus
    {
        InDevelopment,
        InBeta,
        ProductionReady
    }
}