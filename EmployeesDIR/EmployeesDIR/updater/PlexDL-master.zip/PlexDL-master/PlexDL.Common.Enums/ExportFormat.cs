﻿namespace PlexDL.Common.Enums
{
    public enum ExportFormat
    {
        Xml,
        Csv,
        Json,
        Logdel
    }
}