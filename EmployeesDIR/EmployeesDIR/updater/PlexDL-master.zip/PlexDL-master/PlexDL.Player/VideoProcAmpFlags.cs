﻿using System;

namespace PlexDL.Player
{
    [Flags]
    internal enum VideoProcAmpFlags
    {
        None = 0x0,
        Auto = 0x0001,
        Manual = 0x0002
    }
}