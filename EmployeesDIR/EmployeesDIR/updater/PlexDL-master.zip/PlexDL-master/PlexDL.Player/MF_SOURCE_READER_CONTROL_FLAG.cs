﻿namespace PlexDL.Player
{
    [UnmanagedName("MF_SOURCE_READER_CONTROL_FLAG")]
    internal enum MF_SOURCE_READER_CONTROL_FLAG
    {
        None = 0,
        Drain = 0x00000001
    }
}