﻿namespace PlexDL.Player
{
    [UnmanagedName("MF_CAPTURE_ENGINE_SINK_TYPE")]
    internal enum MF_CAPTURE_ENGINE_SINK_TYPE
    {
        Record = 0x00000000,
        Preview = 0x00000001,
        Photo = 0x00000002
    }
}