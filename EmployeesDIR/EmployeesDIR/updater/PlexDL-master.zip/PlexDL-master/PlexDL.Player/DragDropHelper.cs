﻿using System.Runtime.InteropServices;

namespace PlexDL.Player
{
    [ComImport, Guid("4657278A-411B-11d2-839A-00C04FD918D0")]
    internal class DragDropHelper
    {
    }
}