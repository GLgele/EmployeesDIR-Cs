﻿namespace PlexDL.Player
{
    [UnmanagedName("MF_OBJECT_TYPE")]
    internal enum MFObjectType
    {
        MediaSource,
        ByteStream,
        Invalid
    }
}