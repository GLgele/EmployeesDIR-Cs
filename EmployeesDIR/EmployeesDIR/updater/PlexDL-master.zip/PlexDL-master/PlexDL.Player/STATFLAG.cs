﻿namespace PlexDL.Player
{
    [UnmanagedName("STATFLAG")]
    internal enum STATFLAG
    {
        Default = 0,
        NoName = 1,
        NoOpen = 2
    }
}