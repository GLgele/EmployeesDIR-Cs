﻿using System.Runtime.InteropServices;

namespace PlexDL.Player
{
    [ComImport]
    [Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    internal class MMDeviceEnumerator
    {
    }
}