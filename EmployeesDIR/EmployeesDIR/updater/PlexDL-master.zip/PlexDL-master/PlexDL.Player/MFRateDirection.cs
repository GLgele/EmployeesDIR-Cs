﻿namespace PlexDL.Player
{
    [UnmanagedName("MFRATE_DIRECTION")]
    internal enum MFRateDirection
    {
        Forward = 0,
        Reverse
    }
}