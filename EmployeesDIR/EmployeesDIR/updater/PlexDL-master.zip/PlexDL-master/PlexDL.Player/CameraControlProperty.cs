﻿namespace PlexDL.Player
{
    internal enum CameraControlProperty
    {
        Pan = 0,
        Tilt,
        Roll,
        Zoom,
        Exposure,
        Iris,
        Focus,
        Flash
    }
}