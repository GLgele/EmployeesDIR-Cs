﻿namespace PlexDL.Player
{
    [UnmanagedName("MFBYTESTREAM_SEEK_ORIGIN")]
    internal enum MFByteStreamSeekOrigin
    {
        Begin,
        Current
    }
}