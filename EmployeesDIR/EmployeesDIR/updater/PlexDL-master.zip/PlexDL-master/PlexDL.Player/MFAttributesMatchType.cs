﻿namespace PlexDL.Player
{
    [UnmanagedName("MF_ATTRIBUTES_MATCH_TYPE")]
    internal enum MFAttributesMatchType
    {
        OurItems,
        TheirItems,
        AllItems,
        InterSection,
        Smaller
    }
}