﻿using System.Drawing;

namespace PlexDL.Player
{
    internal delegate Region ShapeCallback(Rectangle shapeBounds);
}