﻿using System.Runtime.InteropServices;

namespace PlexDL.Player
{
    [UnmanagedName("CLSID_MFCaptureEngineClassFactory"),
     ComImport,
     Guid("efce38d3-8914-4674-a7df-ae1b3d654b8a")]
    internal class MFCaptureEngineClassFactory
    {
    }
}