﻿namespace PlexDL.Player
{
    [UnmanagedName("MFCLOCK_STATE")]
    internal enum MFClockState
    {
        Invalid,
        Running,
        Stopped,
        Paused
    }
}