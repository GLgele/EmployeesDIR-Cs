# PlexDL Documentation
## Listing
#### ARGS.md
Provides information on all PlexDL command-line arguments

#### BUILD.md
PlexDL build guide; follow this document to build the application from source.

#### IMAGES.md
Placeholder document for demo images

#### LICENSE.rtf
Rich-text version of GPLv3

#### SECURITY.md
A document regarding transparency for PlexDL encryption systems

#### USAGE.md
PlexDL's official guidebook
